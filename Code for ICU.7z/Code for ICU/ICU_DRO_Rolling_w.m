for ij=1:5
    for ijj=1:5
        for jj=1:6
            
            tic
            
            yalmip('clear');
            I=2;
            T=30;
            K=5+(jj-1);
            Hh=3;
            N=2;
            load('axi23-2')
            b1=[684	122	378	504	420	196	405	304	340	120	510	300	160	158	220	160	100	310	92	109	411	260	206	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0];
            b4=[582	115	448	520	434	196	463	303	347	102	521	318	108	158	211	160	100	310	92	71	408	275	172	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0];
            cap=[684  322	378	504	420	268	793	404	619	181	510	600	1050 810	800	950	400	500	400	305	411	260	300	288	26	690	240	1020	1396	262	828	255	80	135	451	1000	430	1009	850	240	235	260	262	600	619	300	233	800];
            b3=cap-b1;
            
            p=[0.027 0.042];
            q=[0.0072 0.01];
            r=ones(1,2)-p-q;
            gamma=q./p;
            omega=0.1;
            psi=[(gamma(1)*gamma(2)+gamma(1))/(1+gamma(1)+gamma(1)*gamma(2)) (gamma(1)*gamma(2))/(1+gamma(1)+gamma(1)*gamma(2))];
            pg=[0.0235322883196864 0.0366057818306233];
            qg=[0.00861201727032301 0.0119611350976708];
            rg=ones(1,2)-pg-qg;
            gammag=qg./pg;
            psig=[(gammag(1)*gammag(2)+gammag(1))/(1+gammag(1)+gammag(1)*gammag(2)) (gammag(1)*gammag(2))/(1+gammag(1)+gammag(1)*gammag(2))];
            
            xi=axi;
            load('sigma.mat');load('pi.mat');
            overlinemu=pi;
            
            load('sigma2_like.mat');

            
            omu=2;
            osigma=0.5;
            Gamma=ones(I,T)*100*K;
            
            wa1=[0.1 0.5 1 1.5 2];
            wa2=[0.0015 0.005 0.01 0.05 0.1];
           
            a1=wa1(1,ij);
            a2=wa2(1,ijj);
            
            de=200;
            load('unitcost');
            
            M=100000000;
            epsilon=ones(K,I,T);
            oepsilon=ones(K,I,T)*1.2;
            uepsilon=ones(K,I,T)*0.8;
            H=1;
            
            B=intvar(K,H);
            R=binvar(K,H);
            X=sdpvar(K,I,H);
            V=sdpvar(K,I,H);
            Z=sdpvar(K,K+1,I,H,'full');
            ualpha=sdpvar(I,H);
            ubeta1=sdpvar(K,I,H);
            ubeta2=sdpvar(K,I,H);
            urho1=sdpvar(K,I,H);
            urho2=sdpvar(K,I,H);
            ueta1=sdpvar(K,K+1,I,H);
            ueta2=sdpvar(K,K+1,I,H);
            udelta=sdpvar(I,T);
            
            
            
            F=[];
            
            for k=1:K
                for t=1:H
                    F=[F, sum(X(k,:,t))<=B(k,t)];
                    F=[F, R(k,t)<=B(k,t)<=R(k,t)*cap(1,k)];
                end
            end
            
            for k=1:K
                F=[F, X(k,1,1)==round(0.26*b4(1,k))+Z(k,k,1,1)+sum(Z(1:K,k,1,1))-sum(Z(k,1:K,1,1))-V(k,1,1)];
                F=[F, X(k,2,1)==round(0.74*b4(1,k))+Z(k,k,2,1)+sum(Z(1:K,k,2,1))-sum(Z(k,1:K,2,1))-V(k,2,1)];
            end
            
            adcc1=sdpvar(I,H);
            for t=1:H
                for i=1:I
                    ad1=0;
                    ad2=0;
                    for k=1:K
                        ad1=ad1+Z(k,k,i,t);
                        ad2=ad2+overlinemu(k,i,t)*ubeta1(k,i,t)-overlinemu(k,i,t)*ubeta2(k,i,t);
                    end
                    F=[F, ad1>=ualpha(i,t)+ad2+udelta(i,t)*Gamma(i,t)];
                end
            end
            
            
            for t=1:H
                for i=1:I
                    
                    for n=1:N
                        ad3=0;
                        for k=1:K
                            ad3=ad3+(ubeta1(k,i,t)-ubeta2(k,i,t))*axi{n}(k,i,t)-axi{n}(k,i,t);
                        end
                        F=[F, ualpha(i,t)+ad3>=0];
                    end
                end
            end
            
            
            for t=1:H
                for i=1:I
                    for k=1:K
                        F=[F, ubeta1(k,i,t)+ubeta2(k,i,t)-udelta(i,t)<=0];
                    end
                end
            end
            
            ad4=0;
            ab1=0;
            ad5=0;
            bedcost=0;
            for k=1:K
                for t=1:H
                    ad4=ad4+de*X(k,1,t)*q(1,1)+a2*c(1,k)*B(k,t);
                    ad5=ad5+X(k,1,t)*q(1,1);
                    ab1=ab1+a2*c(1,k)*B(k,t);
                    bedcost=bedcost+c(1,k)*B(k,t);
                    for i=1:I
                        ad4=ad4+de*V(k,i,t)*psig(1,i);
                        ad5=ad5+V(k,i,t)*psig(1,i);
                        for h=1:K
                            if k~=h
                                ad4=ad4+a1*b(h,k,i)*Z(h,k,i,t);
                                ab1=ab1+b(h,k,i)*Z(h,k,i,t);
                            end
                        end
                    end
                end
            end
            
            obj=ad4;
            options=sdpsettings('verbose',2,'debug',1,'solver','gurobi');
            options.gurobi.TimeLimit=100;
            optimize([F, ubeta1>=0,ubeta2>=0,udelta>=0,X>=0,V>=0,Z>=0,R>=0,B>=0],obj,options)
            VOC(1)=value(ab1);
            Vbed(1)=value(bedcost);
            
            for t=1:H
                XV1{t,1}=value(X(:,:,t));
                VV1{t,1}=value(V(:,:,t));
                ZV1{t,1}=value(Z(:,:,:,t));
                RV{t}=value(R(:,t));
                OB{t}=value(B(:,t));
            end
            
            
            X=sdpvar(K,I,H);
            V=sdpvar(K,I,H);
            Z=sdpvar(K,K+1,I,H);
            F=[];
            for k=1:K
                for t=1:H
                    F=[F, sum(X(k,:,t))<=OB{t}(k,1)];
                end
            end
            
            for k=1:K
                for t=1
                    F=[F, X(k,1,t)==round(0.26*b4(1,k))+Z(k,k,1,t)+sum(Z(1:K,k,1,t))-sum(Z(k,1:K,1,t))-V(k,1,t)];
                    F=[F, X(k,2,t)==round(0.74*b4(1,k))+Z(k,k,2,t)+sum(Z(1:K,k,2,t))-sum(Z(k,1:K,2,t))-V(k,2,t)];
                end
            end
            
            for k=1:K
                for t=1:H
                    for i=1:I
                        F=[F, Z(k,k,i,t)>=pi(k,i,t)];
                    end
                end
            end
            
            ab=0;
            death=0;
            for t=1:H
                for i=1:I
                    ab=ab+de*sum(V(:,i,t))*psig(i);
                    death=death+sum(V(:,i,t))*psig(i);
                    for k=1:K
                        for h=1:K
                            if k~=h
                                ab=ab+a1*b(h,k,i)*Z(h,k,i,t);
                            end
                        end
                    end
                end
                ab=ab+de*sum(X(:,1,t))*q(1);
                death=death+sum(X(:,1,t))*q(1);
            end
            
            obj=ab;
            options=sdpsettings('verbose',2,'debug',1,'solver','gurobi');
            options.gurobi.TimeLimit=120;
            optimize([F,X>=0,V>=0,Z>=0],obj,options)
            
            transcost=0;
            for k=1:K
                for t=1:H
                    for i=1:I
                        for h=1:K
                            if k~=h
                                transcost=transcost+b(h,k,i)*value(Z(h,k,i,t));
                            end
                        end
                    end
                end
            end
            Vtrans(1)=transcost;
            
            for t=1:H
                XV{t,1}=value(X(:,:,t));
                VV{t,1}=value(V(:,:,t));
                ZV{t,1}=value(Z(:,:,:,t));
            end
            vobj(1)=value(obj);
            vdeath(1)=value(death);
            
            for tt=2:(T/H)
                yalmip('clear');
                B=intvar(K,H);
                R=binvar(K,H);
                X=sdpvar(K,I,H);
                V=sdpvar(K,I,H);
                Z=sdpvar(K,K,I,H,'full');
                ualpha=sdpvar(I,H);
                ubeta1=sdpvar(K,I,H);
                ubeta2=sdpvar(K,I,H);
                urho1=sdpvar(K,I,H);
                urho2=sdpvar(K,I,H);
                ueta1=sdpvar(K,K,I,H);
                ueta2=sdpvar(K,K,I,H);
                udelta=sdpvar(I,T);
                
                F=[];
                
                for k=1:K
                    for t=1:H
                        F=[F, sum(X(k,:,t))<=B(k,t)];
                        F=[F, R(k,t)<=B(k,t)<=R(k,t)*cap(1,k)];
                    end
                end
                
                
                for k=1:K
                    for t=1:H
                        F=[F, X(k,1,t)==r(1)*XV{H*(tt-1),1}(k,1)+q(2)*XV{H*(tt-1),1}(k,2)+Z(k,k,1,t)+sum(Z(1:K,k,1,t))-sum(Z(k,1:K,1,t))-V(k,1,t)];
                        F=[F, X(k,2,t)==p(1)*XV{H*(tt-1),1}(k,1)+r(2)*XV{H*(tt-1),1}(k,2)+Z(k,k,2,t)+sum(Z(1:K,k,2,t))-sum(Z(k,1:K,2,t))-V(k,2,t)];
                    end
                end
                
                
                
                adcc1=sdpvar(I,H);
                for t=1:H
                    for i=1:I
                        ad1=0;
                        ad2=0;
                        for k=1:K
                            ad1=ad1+Z(k,k,i,t);
                            ad2=ad2+overlinemu(k,i,t)*ubeta1(k,i,t)-overlinemu(k,i,t)*ubeta2(k,i,t);
                        end
                        F=[F, ad1>=ualpha(i,t)+ad2+udelta(i,t)*Gamma(i,t)];
                    end
                end
                
                for t=1:H
                    for i=1:I
                        for n=1:N
                            ad3=0;
                            for k=1:K
                                ad3=ad3+(ubeta1(k,i,t)-ubeta2(k,i,t))*axi{1,n}(k,i,H*(tt-1)+t)-axi{1,n}(k,i,H*(tt-1)+t);
                            end
                            F=[F, ualpha(i,t)+ad3>=0];
                        end
                        
                    end
                end
                
                for t=1:H
                    for i=1:I
                        for k=1:K
                            F=[F, ubeta1(k,i,t)+ubeta2(k,i,t)-udelta(i,t)<=0];
                        end
                    end
                end
                
                ad4=0;
                ab1=0;
                bedcost=0;
                for k=1:K
                    for t=1:H
                        ad4=ad4+de*X(k,1,t)*q(1,1)+a2*c(1,k)*B(k,t);
                        ab1=ab1+a2*c(1,k)*B(k,t);
                        bedcost=bedcost+c(1,k)*B(k,t);
                        for i=1:I
                            ad4=ad4+de*V(k,i,t)*psig(1,i);
                            for h=1:K
                                if k~=h
                                    ad4=ad4+a1*b(h,k,i)*Z(h,k,i,t);
                                    ab1=ab1+a1*b(h,k,i)*Z(h,k,i,t);
                                end
                            end
                        end
                    end
                end
                
                
                
                obj=ad4;
                options=sdpsettings('verbose',2,'debug',1,'solver','gurobi');
                options.gurobi.TimeLimit=100;
                optimize([F, ubeta1>=0,ubeta2>=0,udelta>=0,X>=0,V>=0,Z>=0,R>=0,B>=0],obj,options)
                
                VOC(tt)=value(ab1);
                Vbed(tt)=value(bedcost);
                for t=1:H
                    XV1{H*(tt-1)+t,1}=value(X(:,:,t));
                    VV1{H*(tt-1)+t,1}=value(V(:,:,t));
                    ZV1{H*(tt-1)+t,1}=value(Z(:,:,:,t));
                    RV{H*(tt-1)+t}=value(R(:,t));
                    OB{H*(tt-1)+t}=value(B(:,t));
                end
                
                
                X=sdpvar(K,I,H);
                V=sdpvar(K,I,H);
                Z=sdpvar(K,K+1,I,H);
                F=[];
                for k=1:K
                    for t=1:H
                        F=[F, sum(X(k,:,t))<=OB{H*(tt-1)+t}(k,t)];
                    end
                end
                
                for k=1:K
                    for t=1
                        F=[F, X(k,1,t)==r(1)*XV{H*(tt-1),1}(k,1)+q(2)*XV{H*(tt-1),1}(k,2)+Z(k,k,1,t)+sum(Z(1:K,k,1,t))-sum(Z(k,1:K,1,t))-V(k,1,t)];
                        F=[F, X(k,2,t)==p(1)*XV{H*(tt-1),1}(k,1)+r(2)*XV{H*(tt-1),1}(k,2)+Z(k,k,2,t)+sum(Z(1:K,k,2,t))-sum(Z(k,1:K,2,t))-V(k,2,t)];
                    end
                end
                
                
                for k=1:K
                    for t=1:H
                        for i=1:I
                            F=[F, Z(k,k,i,t)>=pi(k,i,H*(tt-1)+t)];
                        end
                    end
                end
                
                
                ab=0;
                death=0;
                for t=1:H
                    for i=1:I
                        ab=ab+de*(sum(V(:,i,t)))*psig(i);
                        death=death+(sum(V(:,i,t)))*psig(i);
                        for k=1:K
                            for h=1:K
                                if k~=h
                                    ab=ab+a1*b(h,k,i)*Z(h,k,i,t);
                                end
                            end
                        end
                    end
                    ab=ab+de*sum(X(:,1,t))*q(1);
                    death=death+sum(X(:,1,t))*q(1);
                end
                
                obj=ab;
                options=sdpsettings('verbose',2,'debug',1,'solver','gurobi');
                options.gurobi.TimeLimit=120;
                
                optimize([F,X>=0,V>=0,Z>=0],obj,options);
                transcost=0;
                for k=1:K
                    for t=1:H
                        for i=1:I
                            for h=1:K
                                if k~=h
                                    transcost=transcost+b(h,k,i)*value(Z(h,k,i,t));
                                end
                            end
                        end
                    end
                end
                
                Vtrans(tt)=transcost;
                
                vobj(tt)=value(obj);
                vdeath(tt)=value(death);
                for t=1:H
                    
                    XV{H*(tt-1)+t,1}=value(X(:,:,t));
                    VV{H*(tt-1)+t,1}=value(V(:,:,t));
                    ZV{H*(tt-1)+t,1}=value(Z(:,:,:,t));
                    
                end
                
                
            end
            Totalbed=sum(Vbed);
            Totaltrans=sum(Vtrans);
            TotalOC=Totalbed+Totaltrans;
            Totaldeath=sum(vdeath);
            
            Totalcost=Totalbed*a2+Totaltrans*a1+Totaldeath*de;
            
            toc
            
            Tresult(1,1)=TotalOC;
            Tresult(1,2)=Totalbed;
            Tresult(1,3)=Totaltrans;
            Tresult(1,4)=Totaldeath;
            
            TTcost(1,jj)=Totalcost;
            
            Ttime(1,jj)=toc;
            TTresult{1,jj}=Tresult;
        end
        TTTcost{ij,ijj}= TTcost;
        
        TTtime{ij,ijj}= Ttime;
        TTTresult{ij,ijj}=TTresult;
        
    end
end