for ij=1:20
    
    for jj=1:6
        
        tic
        
        yalmip('clear');
        I=2;
        T=30;
        K=5+(jj-1);
        
        Hh=3;
        
        N=2;

        load('axi23_ws_2.mat');
        
        b1=[684	122	378	504	420	196	405	304	340	120	510	300	160	158	220	160	100	310	92	109	411	260	206	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0];
        b4=[582	115	448	520	434	196	463	303	347	102	521	318	108	158	211	160	100	310	92	71	408	275	172	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0	0];
        cap=[684	322	378	504	420	268	793	404	619	181	510	600	1050 810	800	950	400	500	400	305	411	260	300	288	26	690	240	1020	1396	262	828	255	80	135	451	1000	430	1009	850	240	235	260	262	600	619	300	233	800];
        b3=cap-b1;
        p=[0.027 0.042];
        q=[0.0072 0.01];
        r=ones(1,2)-p-q;
        gamma=q./p;
        omega=0.1;
        psi=[(gamma(1)*gamma(2)+gamma(1))/(1+gamma(1)+gamma(1)*gamma(2)) (gamma(1)*gamma(2))/(1+gamma(1)+gamma(1)*gamma(2))];
        pg=[0.0235322883196864 0.0366057818306233];
        qg=[0.00861201727032301 0.0119611350976708];
        rg=ones(1,2)-pg-qg;
        gammag=qg./pg;
        psig=[(gammag(1)*gammag(2)+gammag(1))/(1+gammag(1)+gammag(1)*gammag(2)) (gammag(1)*gammag(2))/(1+gammag(1)+gammag(1)*gammag(2))];
        
        
        
        xi=axi;
        load('sigma.mat');load('pi.mat');
        overlinemu=pi;
        
        load('sigma2_like.mat');
        
        [mmnew, sigma2_post] = computePosterior(pi, sigma, axi, sigma2_like);
        
        
        omu=2;
        osigma=0.5;
        Gamma=ones(I,T)*100*K;
        
        
        epsilon1=0;
        a1=1;
        a2=0.0015;
        de=200;
        load('unitcost');
        M=100000000;
        
        
        S=20;
        
        
        for s=1:S
            axi1{s}=axi{(ij-1)*S+s};
        end
        
        
        
        

        
        for s=1:S
            
            yalmip('clear');
            B=intvar(K,T);
            R=binvar(K,T);
            X=sdpvar(K,I,T);
            V=sdpvar(K,I,T);
            Z=sdpvar(K,K+1,I,T);
            
            
            F=[];
            
            for k=1:K
                for t=1:T
                    F=[F, sum(X(k,:,t))<=B(k,t)];
                    F=[F, R(k,t)<=B(k,t)<=R(k,t)*cap(1,k)];
                end
            end
            
            for k=1:K
                for t=1
                    F=[F, X(k,1,t)==round(0.26*b4(1,k))+Z(k,k,1,t)+sum(Z(1:K,k,1,t))-sum(Z(k,1:K,1,t))-V(k,1,t)];
                    F=[F, X(k,2,t)==round(0.74*b4(1,k))+Z(k,k,2,t)+sum(Z(1:K,k,2,t))-sum(Z(k,1:K,2,t))-V(k,2,t)];
                end
            end
            
            for k=1:K
                for t=2:T
                    F=[F, X(k,1,t)==r(1)*X(k,1,t-1)+q(2)*X(k,2,t-1)+Z(k,k,1,t)+sum(Z(1:K,k,1,t))-sum(Z(k,1:K,1,t))-V(k,1,t)];
                    F=[F, X(k,2,t)==p(1)*X(k,1,t-1)+r(2)*X(k,2,t-1)+Z(k,k,2,t)+sum(Z(1:K,k,2,t))-sum(Z(k,1:K,2,t))-V(k,2,t)];
                end
            end
            
            
            for k=1:K
                for t=1:T
                    for i=1:I
                        F=[F, Z(k,k,i,t)>=axi1{s}(k,i,t)];
                    end
                end
            end
            
            ad4=0;
            ad42=sdpvar(1,1);
            bedcost=0;
            ad41=0;
            transcost=0;
            for k=1:K
                for t=1:T
                    ad4=ad4+a2*c(1,k)*B(k,t);
                    bedcost=bedcost+c(1,k)*B(k,t);
                    for i=1:I
                        for h=1:K
                            if k~=h
                                ad41=ad41+a1*b(h,k,i)*Z(h,k,i,t);
                                transcost=transcost+b(h,k,i)*Z(h,k,i,t);
                            end
                        end
                    end
                end
            end
            
            
            D=0;
            D=de*(sum(sum(V(:,1,1:T)))*psig(1)+sum(sum(V(:,2,1:T)))*psig(2)+sum(sum(X(:,1,1:T)))*q(1));
            death=sum(sum(V(:,1,1:T)))*psig(1)+sum(sum(V(:,2,1:T)))*psig(2)+sum(sum(X(:,1,1:T)))*q(1);
            obj=D+ad4+ad41;
            options=sdpsettings('verbose',2,'debug',1,'solver','gurobi');
            options.gurobi.TimeLimit=120;
            
            optimize([F,X>=0,V>=0,Z>=0,R>=0,B>=0],obj,options)
            
            VOC(1)=value(sum(ad42)/S+ad4);
            Vbed(1)=value(bedcost);
            
            Totalbed(1,s)=value(bedcost);
            Totaltrans(1,s)=value(transcost);
            
            Tcost=value(ad4+ad41);
            
            TotalOC(1,s)=value(bedcost)+value(transcost);
            Totaldeath(1,s)=value(death);
            
            Tobj(1,s)=value(obj);
            
        end
        LB=1/S*sum(Tobj);
        
        toc
        
        ATotalbed(1,jj)=1/S*sum( Totalbed);
        ATotaltrans(1,jj)=1/S*sum( Totaltrans);
        ATotalOC(1,jj)=1/S*sum(TotalOC );
        ATotaldeath(1,jj)=1/S*sum(Totaldeath);
        ATcost(1,jj)=1/S*sum(Tcost);
        ATobj(1,jj)=LB;
        
        
        Ttime(1,jj)=toc;
    end
    
    TTTcost{1,ij}=ATobj;
    TTtime{1,ij}=Ttime;
    TTTbed{1,ij}=ATotalbed;
    TTTtrans{1,ij}=ATotaltrans;
    TTTdeath{1,ij}=ATotaldeath;
    
end